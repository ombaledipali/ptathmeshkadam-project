package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.ProductsPage;

public class CartTest extends BaseClass {

    @Test
    public void addBackpackToCartTest() {

        launchBrowser();

        // Login
        LoginPage login = new LoginPage(driver);
        login.login("standard_user", "secret_sauce");

        // Add Backpack
        ProductsPage products = new ProductsPage(driver);
        products.addBackpackToCart();

        // Open Cart
        products.openCart();

        // Verify Product
        String actualProduct = driver.findElement(
            org.openqa.selenium.By.className("inventory_item_name")
        ).getText();

        Assert.assertEquals(actualProduct, "Sauce Labs Backpack");

        System.out.println("Add to Cart Test Passed");

        driver.quit();
    }
}