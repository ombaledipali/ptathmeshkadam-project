package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.ProductsPage;
import pages.CheckoutPage;

public class CheckoutTest extends BaseClass {

    @Test
    public void completeCheckoutTest() {

        launchBrowser();

        // Login
        LoginPage login = new LoginPage(driver);
        login.login("standard_user", "secret_sauce");

        // Add Backpack
        ProductsPage products = new ProductsPage(driver);
        products.addBackpackToCart();

        // Open Cart
        products.openCart();

        // Checkout
        CheckoutPage checkout = new CheckoutPage(driver);
        checkout.clickCheckout();

        // Enter Customer Details
        checkout.enterDetails("Dipali", "Ombale", "411001");

        checkout.clickContinue();

        // Finish Order
        checkout.clickFinish();

        // Verify Order Confirmation
        String message = checkout.getSuccessMessage();

        Assert.assertEquals(message, "Thank you for your order!");

        System.out.println("Checkout Test Passed");

        driver.quit();
    }
}