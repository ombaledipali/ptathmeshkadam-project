package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.By;

import base.BaseClass;
import pages.LoginPage;
import pages.ProductsPage;

public class RemoveCartTest extends BaseClass {

    @Test
    public void removeBackpackTest() {

        launchBrowser();

        LoginPage login = new LoginPage(driver);
        login.login("standard_user", "secret_sauce");

        ProductsPage products = new ProductsPage(driver);

        products.addBackpackToCart();
        products.removeBackpackFromCart();

        // Verify Cart is Empty
        boolean isCartEmpty = driver.findElements(
            By.className("shopping_cart_badge")
        ).isEmpty();

        Assert.assertTrue(isCartEmpty, "Cart is not empty");

        System.out.println("Remove Cart Test Passed");

        driver.quit();
    }
}