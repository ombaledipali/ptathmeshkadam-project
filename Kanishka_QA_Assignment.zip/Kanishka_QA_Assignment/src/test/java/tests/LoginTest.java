package tests;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.By;

import base.BaseClass;
import pages.LoginPage;

public class LoginTest extends BaseClass {

    // Test Case 1: Valid Login
    @Test
    public void validLoginTest() {

        launchBrowser();

        LoginPage login = new LoginPage(driver);

        login.login("standard_user", "secret_sauce");

        String actualTitle = driver.getTitle();

        Assert.assertEquals(actualTitle, "Swag Labs");

        System.out.println("Login Test Passed");

        driver.quit();
    }

    // Test Case 2: Invalid Login
    @Test
    public void invalidLoginTest() {

        launchBrowser();

        LoginPage login = new LoginPage(driver);

        login.login("standard_user", "wrong_password");

        String errorMessage = driver.findElement(
            By.cssSelector("[data-test='error']")
        ).getText();

        System.out.println("Error Message: " + errorMessage);

        Assert.assertTrue(
            errorMessage.contains("Username and password do not match"),
            "Invalid login error message not displayed"
        );

        System.out.println("Invalid Login Test Passed");

        driver.quit();
    }

    // Test Case 3: Locked User Login
    @Test
    public void lockedUserLoginTest() {

        launchBrowser();

        LoginPage login = new LoginPage(driver);

        login.login("locked_out_user", "secret_sauce");

        String errorMessage = driver.findElement(
            By.cssSelector("[data-test='error']")
        ).getText();

        System.out.println("Locked User Error: " + errorMessage);

        Assert.assertTrue(
            errorMessage.contains("Sorry, this user has been locked out"),
            "Locked user error message not displayed"
        );

        System.out.println("Locked User Login Test Passed");

        driver.quit();
    }
}