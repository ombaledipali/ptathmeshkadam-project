package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductsPage {

    WebDriver driver;

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
    }

    By backpackAddButton = By.id("add-to-cart-sauce-labs-backpack");
    By cartButton = By.className("shopping_cart_link");

    // Add Product
    public void addBackpackToCart() {
        driver.findElement(backpackAddButton).click();
    }

    // Open Cart
    public void openCart() {
        driver.findElement(cartButton).click();
    }

    // Remove Product
    By backpackRemoveButton = By.id("remove-sauce-labs-backpack");

    public void removeBackpackFromCart() {
        driver.findElement(backpackRemoveButton).click();
    }

}